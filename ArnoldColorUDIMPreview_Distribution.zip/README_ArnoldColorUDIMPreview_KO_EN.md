# ArnoldColorUDIMPreview (KR/EN)

**Author:** Kyle Inkyu Lee  
**Version:** 1.0.0  
**Target:** Maya 2023+ (Arnold aiStandardSurface), uses `maya.cmds` only

---

## What it does
- **KR:** 선택한 오브젝트의 **aiStandardSurface.baseColor** 경로에 연결된 **file 노드만** 찾아, `uvTilingMode`를 **UDIM (Mari)** 로 설정하고, 가능한 경우 **Generate Preview**를 활성화합니다.  
- **EN:** For selected objects, finds **file** nodes that feed **aiStandardSurface.baseColor** only, sets `uvTilingMode` to **UDIM (Mari)**, and enables **Generate Preview** when such an attribute exists.

---

## Files
- `ArnoldColorUDIMPreview_KR.py` — Korean comments/messages
- `ArnoldColorUDIMPreview_EN.py` — English comments/messages

---

## Installation
1. Copy the `.py` files into your Maya user scripts folder:  
   - Windows: `%USERPROFILE%\Documents\maya\<MayaVersion>\scripts\`  
   - macOS: `~/Library/Preferences/Autodesk/maya/<MayaVersion>/scripts/`  
   - Linux: `~/maya/<MayaVersion>/scripts/`  

2. In Maya Script Editor > Python tab, run:
   ```python
   import ArnoldColorUDIMPreview_KR as ACUP
   ACUP.main()
   ```
   or
   ```python
   import ArnoldColorUDIMPreview_EN as ACUP
   ACUP.main()
   ```

3. To create a Shelf button, middle-drag the above two lines into your desired shelf.

---

## Notes
- Only processes **file** nodes connected to **aiStandardSurface.baseColor**.  
- The script checks multiple candidate attributes for **Generate Preview** since attribute names vary between Maya versions.  
