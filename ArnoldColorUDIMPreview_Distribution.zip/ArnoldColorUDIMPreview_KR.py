# -*- coding: utf-8 -*-
# ============================================================================
# Script Name : ArnoldColorUDIMPreview
# Author      : Kyle Inkyu Lee
# Version     : 1.0.0
# Maya        : 2023+
# Description : 선택된 오브젝트의 aiStandardSurface에서 baseColor에 연결된 파일(file) 노드만
#               UV Tiling Mode를 UDIM(Mari)로 설정하고, 가능한 경우 Generate Preview를 활성화합니다.
# Usage       : 1) 대상 오브젝트 또는 그 하위 shape를 선택
#               2) 이 스크립트를 실행
# ============================================================================

import maya.cmds as cmds

def get_selected_shapes():
    sel = cmds.ls(sl=True, long=True)
    if not sel:
        return []
    shapes = []
    for s in sel:
        if cmds.nodeType(s) in ('mesh', 'nurbsSurface', 'subdiv'):
            shapes.append(s)
        else:
            children = cmds.listRelatives(s, shapes=True, fullPath=True) or []
            for c in children:
                shapes.append(c)
    return list(set(shapes))

def get_ai_shaders_from_shape(shape):
    sgs = cmds.listConnections(shape, type='shadingEngine') or []
    shaders = []
    for sg in sgs:
        surf = cmds.listConnections(sg + '.surfaceShader', s=True, d=False) or []
        for sh in surf:
            if cmds.nodeType(sh) == 'aiStandardSurface':
                shaders.append(sh)
    return list(set(shaders))

def upstream_file_nodes_for_attr(node, attr):
    start_plug = node + '.' + attr
    seeds = cmds.listConnections(start_plug, s=True, d=False) or []
    to_visit = list(set(seeds))
    visited = set()
    result = []
    while to_visit:
        n = to_visit.pop()
        if n in visited:
            continue
        visited.add(n)
        if cmds.nodeType(n) == 'file':
            result.append(n)
            continue
        ups = cmds.listConnections(n, s=True, d=False) or []
        for u in ups:
            if u not in visited:
                to_visit.append(u)
    return list(set(result))

def find_udim_index(file_node):
    enums = cmds.attributeQuery('uvTilingMode', node=file_node, listEnum=True) or []
    if not enums:
        return None
    labels = enums[0].split(':')
    for i, lab in enumerate(labels):
        if 'udim' in lab.lower():
            return i
    return None

def enable_generate_preview_if_possible(file_node):
    candidate_attrs = ['uvTileProxyGenerate','uvTilePreviewEnable','generatePreview','uvTilePreviewOn']
    for a in candidate_attrs:
        if cmds.attributeQuery(a, node=file_node, exists=True):
            atype = cmds.getAttr(file_node + '.' + a, type=True)
            if atype in ('bool', 'long', 'short', 'byte'):
                cmds.setAttr(file_node + '.' + a, 1)

def set_filenode_to_udim_and_preview(file_node):
    udim_idx = find_udim_index(file_node)
    if udim_idx is not None:
        cmds.setAttr(file_node + '.uvTilingMode', udim_idx)
    enable_generate_preview_if_possible(file_node)

def main():
    shapes = get_selected_shapes()
    if not shapes:
        print('[INFO] 선택된 오브젝트/쉐이프가 없습니다.')
        return
    changed = []
    for sh in shapes:
        shaders = get_ai_shaders_from_shape(sh)
        for shader in shaders:
            file_nodes = upstream_file_nodes_for_attr(shader, 'baseColor')
            for f in file_nodes:
                set_filenode_to_udim_and_preview(f)
                changed.append(f)
    changed = list(set(changed))
    if changed:
        print('[DONE] UDIM(Mari) 적용 및 Generate Preview 활성 시도 노드:')
        for n in changed:
            print('  - {0}'.format(n))
    else:
        print('[INFO] 처리할 color 파일 노드를 찾지 못했습니다. (선택/연결 상태 확인 필요)')

if __name__ == "__main__":
    main()
